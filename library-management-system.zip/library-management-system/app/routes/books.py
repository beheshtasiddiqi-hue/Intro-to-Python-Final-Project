from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user
from app.extensions import db
from app.models.book import Book
from app.utils.permissions import role_required

books_bp = Blueprint("books", __name__, url_prefix="/books")


@books_bp.route("/")
def list_books():
    q = request.args.get("q", "").strip()
    language = request.args.get("language", "").strip()
    year = request.args.get("year", "").strip()

    query = Book.query

    if q:
        like = f"%{q}%"
        query = query.filter((Book.title.ilike(like)) | (Book.author.ilike(like)))

    if language:
        query = query.filter(Book.language == language)

    if year.isdigit():
        query = query.filter(Book.publication_year == int(year))

    books = query.order_by(Book.id.desc()).all()

    return render_template(
        "books/list.html",
        books=books,
        q=q,
        language=language,
        year=year,
        current_user=current_user,
    )


@books_bp.route("/new", methods=["GET", "POST"])
@role_required("admin", "librarian")
def create_book():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        publication_year = request.form.get("publication_year", "").strip()
        language = request.form.get("language", "").strip()
        isbn = request.form.get("isbn", "").strip()

        if not title or not author:
            flash("Title and Author are required.", "error")
            return redirect(url_for("books.create_book"))

        year_val = int(publication_year) if publication_year.isdigit() else None

        book = Book(
            title=title,
            author=author,
            publication_year=year_val,
            language=language or None,
            isbn=isbn or None,
            is_available=True,
        )

        db.session.add(book)
        db.session.commit()

        flash("Book added successfully.", "success")
        return redirect(url_for("books.list_books"))

    return render_template("books/new.html", current_user=current_user)


@books_bp.route("/<int:book_id>/edit", methods=["GET", "POST"])
@role_required("admin", "librarian")
def edit_book(book_id):
    book = Book.query.get_or_404(book_id)

    if request.method == "POST":
        book.title = request.form.get("title", "").strip()
        book.author = request.form.get("author", "").strip()

        publication_year = request.form.get("publication_year", "").strip()
        book.publication_year = int(publication_year) if publication_year.isdigit() else None

        book.language = request.form.get("language", "").strip() or None
        book.isbn = request.form.get("isbn", "").strip() or None

        if not book.title or not book.author:
            flash("Title and Author are required.", "error")
            return redirect(url_for("books.edit_book", book_id=book.id))

        db.session.commit()
        flash("Book updated.", "success")
        return redirect(url_for("books.list_books"))

    return render_template("books/edit.html", book=book, current_user=current_user)


@books_bp.route("/<int:book_id>/delete", methods=["POST"])
@role_required("admin", "librarian")
def delete_book(book_id):
    book = Book.query.get_or_404(book_id)
    db.session.delete(book)
    db.session.commit()
    flash("Book deleted.", "success")
    return redirect(url_for("books.list_books"))


