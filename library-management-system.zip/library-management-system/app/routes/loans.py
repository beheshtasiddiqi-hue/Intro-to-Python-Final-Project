from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.book import Book
from app.models.loan import Loan

loans_bp = Blueprint("loans", __name__, url_prefix="/loans")


@loans_bp.route("/my")
@login_required
def my_loans():
    active_loans = (
        Loan.query.filter_by(user_id=current_user.id, returned_at=None)
        .order_by(Loan.checked_out_at.desc())
        .all()
    )

    history = (
        Loan.query.filter_by(user_id=current_user.id)
        .order_by(Loan.checked_out_at.desc())
        .all()
    )

    return render_template(
        "loans/my.html",
        active_loans=active_loans,
        history=history,
        current_user=current_user,
    )


@loans_bp.route("/checkout/<int:book_id>", methods=["POST"])
@login_required
def checkout(book_id: int):
    book = Book.query.get_or_404(book_id)

    if not book.is_available:
        flash("This book is not available right now.", "error")
        return redirect(url_for("books.list_books"))

    # Create a new loan
    loan = Loan(user_id=current_user.id, book_id=book.id)
    book.is_available = False

    db.session.add(loan)
    db.session.commit()

    flash(f"You checked out: {book.title}", "success")
    return redirect(url_for("books.list_books"))


@loans_bp.route("/return/<int:book_id>", methods=["POST"])
@login_required
def return_book(book_id: int):
    book = Book.query.get_or_404(book_id)

    # Find active loan for this book
    active_loan = Loan.query.filter_by(book_id=book.id, returned_at=None).first()
    if not active_loan:
        flash("No active loan found for this book.", "error")
        return redirect(url_for("books.list_books"))

    # Only the person who borrowed it can return it (admin/librarian can return any)
    if active_loan.user_id != current_user.id and current_user.role not in ["admin", "librarian"]:
        flash("You can only return books you borrowed.", "error")
        return redirect(url_for("books.list_books"))

    active_loan.returned_at = datetime.utcnow()
    book.is_available = True

    db.session.commit()
    flash(f"Returned: {book.title}", "success")
    return redirect(url_for("books.list_books"))


@loans_bp.route("/history")
@login_required
def history():
    # Optional filters
    user_id = request.args.get("user_id", "").strip()
    book_id = request.args.get("book_id", "").strip()

    # Only admin/librarian can view full history for everyone
    if current_user.role not in ["admin", "librarian"]:
        flash("Access denied. Only admin/librarian can view full history.", "error")
        return redirect(url_for("loans.my_loans"))

    query = Loan.query

    if user_id.isdigit():
        query = query.filter(Loan.user_id == int(user_id))
    if book_id.isdigit():
        query = query.filter(Loan.book_id == int(book_id))

    loans = query.order_by(Loan.checked_out_at.desc()).all()

    return render_template(
        "loans/history.html",
        loans=loans,
        current_user=current_user,
        user_id=user_id,
        book_id=book_id,
    )
