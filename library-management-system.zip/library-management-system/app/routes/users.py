from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user
from app.extensions import db
from app.models.user import User
from app.utils.permissions import role_required

users_bp = Blueprint("users", __name__, url_prefix="/users")


@users_bp.route("/")
@role_required("admin", "librarian")
def list_users():
    q = request.args.get("q", "").strip().lower()

    query = User.query
    if q:
        like = f"%{q}%"
        query = query.filter((User.email.ilike(like)) | (User.full_name.ilike(like)))

    users = query.order_by(User.id.desc()).all()

    return render_template("users/list.html", users=users, q=q, current_user=current_user)


@users_bp.route("/new", methods=["GET", "POST"])
@role_required("admin")
def create_user():
    # Only admin can create accounts from admin panel (librarian cannot)
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "member").strip()

        if role not in ["member", "librarian", "admin"]:
            role = "member"

        if not full_name or not email or not password:
            flash("Full name, email, and password are required.", "error")
            return redirect(url_for("users.create_user"))

        if User.query.filter_by(email=email).first():
            flash("Email already exists.", "error")
            return redirect(url_for("users.create_user"))

        user = User(full_name=full_name, email=email, role=role, password_hash="temp")
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        flash("User created.", "success")
        return redirect(url_for("users.list_users"))

    return render_template("users/new.html", current_user=current_user)


@users_bp.route("/<int:user_id>/edit", methods=["GET", "POST"])
@role_required("admin")
def edit_user(user_id: int):
    # Only admin can edit accounts from admin panel
    user = User.query.get_or_404(user_id)

    if request.method == "POST":
        user.full_name = request.form.get("full_name", "").strip()
        user.email = request.form.get("email", "").strip().lower()
        user.role = request.form.get("role", "member").strip()

        new_password = request.form.get("new_password", "")

        if user.role not in ["member", "librarian", "admin"]:
            user.role = "member"

        if not user.full_name or not user.email:
            flash("Full name and email are required.", "error")
            return redirect(url_for("users.edit_user", user_id=user.id))

        # Prevent duplicate email
        existing = User.query.filter(User.email == user.email, User.id != user.id).first()
        if existing:
            flash("Another user already has this email.", "error")
            return redirect(url_for("users.edit_user", user_id=user.id))

        if new_password.strip():
            user.set_password(new_password.strip())

        db.session.commit()
        flash("User updated.", "success")
        return redirect(url_for("users.list_users"))

    return render_template("users/edit.html", user=user, current_user=current_user)


@users_bp.route("/<int:user_id>/delete", methods=["POST"])
@role_required("admin")
def delete_user(user_id: int):
    # Only admin can delete users
    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash("You cannot delete your own account while logged in.", "error")
        return redirect(url_for("users.list_users"))

    db.session.delete(user)
    db.session.commit()
    flash("User deleted.", "success")
    return redirect(url_for("users.list_users"))
