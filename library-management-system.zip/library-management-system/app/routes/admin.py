from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user
from app.extensions import db
from app.models.user import User
from app.utils.permissions import role_required

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/")
@role_required("admin")
def dashboard():
    return render_template("admin/dashboard.html", current_user=current_user)


@admin_bp.route("/users")
@role_required("admin")
def users_list():
    q = request.args.get("q", "").strip().lower()

    query = User.query
    if q:
        like = f"%{q}%"
        query = query.filter((User.email.ilike(like)) | (User.full_name.ilike(like)))

    users = query.order_by(User.id.asc()).all()
    return render_template("admin/users_list.html", users=users, q=q, current_user=current_user)


@admin_bp.route("/users/new", methods=["GET", "POST"])
@role_required("admin")
def users_new():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "member").strip()

        if role not in ["member", "librarian", "admin"]:
            role = "member"

        if not full_name or not email or not password:
            flash("Full name, email, and password are required.", "error")
            return redirect(url_for("admin.users_new"))

        if User.query.filter_by(email=email).first():
            flash("Email already exists.", "error")
            return redirect(url_for("admin.users_new"))

        user = User(full_name=full_name, email=email, role=role, password_hash="temp")
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        flash("User created.", "success")
        return redirect(url_for("admin.users_list"))

    return render_template("admin/users_new.html", current_user=current_user)


@admin_bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@role_required("admin")
def users_edit(user_id: int):
    user = User.query.get_or_404(user_id)

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        role = request.form.get("role", "member").strip()
        new_password = request.form.get("new_password", "")

        if role not in ["member", "librarian", "admin"]:
            role = "member"

        if not full_name or not email:
            flash("Full name and email are required.", "error")
            return redirect(url_for("admin.users_edit", user_id=user.id))

        # Prevent duplicate email
        existing = User.query.filter(User.email == email, User.id != user.id).first()
        if existing:
            flash("Another user already uses this email.", "error")
            return redirect(url_for("admin.users_edit", user_id=user.id))

        user.full_name = full_name
        user.email = email
        user.role = role

        if new_password.strip():
            user.set_password(new_password.strip())

        db.session.commit()
        flash("User updated.", "success")
        return redirect(url_for("admin.users_list"))

    return render_template("admin/users_edit.html", user=user, current_user=current_user)


@admin_bp.route("/users/<int:user_id>/delete", methods=["POST"])
@role_required("admin")
def users_delete(user_id: int):
    user = User.query.get_or_404(user_id)

    # Safety: prevent deleting yourself
    if current_user.id == user.id:
        flash("You cannot delete your own account while logged in.", "error")
        return redirect(url_for("admin.users_list"))

    db.session.delete(user)
    db.session.commit()

    flash("User deleted.", "success")
    return redirect(url_for("admin.users_list"))
