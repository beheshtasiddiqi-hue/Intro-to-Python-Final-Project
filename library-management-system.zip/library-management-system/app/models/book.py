from datetime import datetime
from app.extensions import db

class Book(db.Model):
    __tablename__ = "books"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    author = db.Column(db.String(120), nullable=False, index=True)
    publication_year = db.Column(db.Integer, nullable=True, index=True)
    language = db.Column(db.String(50), nullable=True, index=True)
    isbn = db.Column(db.String(30), unique=True, nullable=True)

    is_available = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    loans = db.relationship("Loan", back_populates="book", cascade="all, delete-orphan")
